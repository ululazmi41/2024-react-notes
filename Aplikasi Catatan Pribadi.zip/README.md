# Belajar Membuat Aplikasi Web Dengan React

Aplikasi catatan sederhana

## Daftar Catatan

![Screenshot](https://github.com/ululazmi41/react_submission_2/blob/main/public/Screenshot.png?raw=true)

## Tambah Catatan

![Screenshot](https://github.com/ululazmi41/react_submission_2/blob/main/public/Screenshot-2.png?raw=true)

## Ubah Catatan

![Screenshot](https://github.com/ululazmi41/react_submission_2/blob/main/public/Screenshot-3.png?raw=true)
